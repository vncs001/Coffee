public class EscolhaInvalidaException extends Exception{
    public EscolhaInvalidaException(String mensagem) {
        super(mensagem);
    }
}
